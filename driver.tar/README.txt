1 - unpack tarball and add models and driver text files to same directory
2 - to compile - run 'make' command - it will create compiled driver file
3 - to run - run './driver driverXX.txt' command where XX - is number of driver file passed as argument 
4 - if all successful - it will create corresponding to driver folder name and save the .obj file with convenient naming
5 - to clean run 'make clean'